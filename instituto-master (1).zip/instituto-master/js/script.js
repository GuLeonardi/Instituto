//seleciona todos as div com classe 'items'
const slider = document.querySelectorAll(".items");
//console.log(slider);

// pega os IDs dos botoes
var buttonBoardR = document.getElementById("boardR");
var buttonBoardL = document.getElementById("boardL");
var buttonTeamR = document.getElementById("teamR");
var buttonTeamL = document.getElementById("teamL");

//pega os ids dos sliders/carousel
var teamDiv = document.getElementById("teamDiv");
var boardDiv = document.getElementById("boardDiv");

//pega a distancia do slider de cada div
var distanciaTeam = () => {
	return teamDiv.scrollWidth - teamDiv.clientWidth;
};

var distanciaBoard = () => {
	return boardDiv.scrollWidth - boardDiv.clientWidth;
};

function disableTeamButton() {
	//RIGHT DISABLE
	if (Math.abs(teamDiv.scrollLeft) >= distanciaTeam() - 100) {
		console.log(teamDiv.scrollLeft + " progresso Team"); //seu progresso na barra
		console.log(distanciaTeam() + " distancia Team"); //distancia total da barra
		buttonTeamR.disabled = true;
	} else {
		console.log(teamDiv.scrollLeft + " progresso Team"); //seu progresso na barra
		console.log(distanciaTeam() + " distancia Team"); //distancia total da barra
		buttonTeamL.disabled = false;
		buttonTeamR.disabled = false;
	}
	//LEFT DISABLE
	if (teamDiv.scrollLeft == 0) buttonTeamL.disabled = true;
}

function disableBoardButton() {
	if (Math.abs(boardDiv.scrollLeft) >= distanciaBoard() - 100) {
		console.log(boardDiv.scrollLeft + " progresso board"); //seu progresso na barra
		console.log(distanciaBoard() + " distancia board"); //distancia total da barra
		buttonBoardR.disabled = true;
	} else {
		console.log(boardDiv.scrollLeft + " progresso board"); //seu progresso na barra
		console.log(distanciaBoard() + " distancia board"); //distancia total da barra
		buttonBoardL.disabled = false;
		buttonBoardR.disabled = false;
	}

	//LEFT DISABLE
	if (boardDiv.scrollLeft === 0) buttonBoardL.disabled = true;
	//RIGHT DISABLE
}

/////////////////////////////////       BOTOES         /////////////////

// ESQUERDOS COMEÇAM DESLIGADOS
buttonTeamL.disabled = true;
buttonBoardL.disabled = true;

//BOTÃO ESQUERDO TEAM
buttonTeamL.addEventListener("click", function() {
	sideScroll(teamDiv, "left", 10, 230, 10);
	disableTeamButton();
	disableBoardButton();
	buttonTeamR.disabled = false;
});

//BOTÃO DIREITO TEAM
buttonTeamR.addEventListener("click", function() {
	sideScroll(teamDiv, "right", 10, 230, 10);
	disableTeamButton();
	disableBoardButton();

	buttonTeamL.disabled = false;
});

//BOTÃO ESQUERDO BOARD
buttonBoardL.addEventListener("click", function() {
	sideScroll(boardDiv, "left", 10, 230, 10);
	disableTeamButton();
	disableBoardButton();

	buttonBoardR.disabled = false;
});

//BOTÃO DIREITO BOARD
buttonBoardR.addEventListener("click", function() {
	sideScroll(boardDiv, "right", 10, 230, 10);
	disableTeamButton();
	disableBoardButton();

	buttonBoardL.disabled = false;
});

///função para scrolar/ scrolar devagar
function sideScroll(element, direction, speed, distance, step) {
	scrollAmount = 0;
	var slideTimer = setInterval(function() {
		if (direction == "left") {
			element.scrollLeft -= step;
		} else {
			element.scrollLeft += step;
		}
		scrollAmount += step;
		if (scrollAmount >= distance) {
			window.clearInterval(slideTimer);
		}
	}, speed);
}

//for pra cada div
slider.forEach((slider) => {
	let mouseApertado = false;
	let startX;
	let scrollLeft;

	slider.addEventListener("mousedown", (e) => {
		mouseApertado = true;
		slider.classList.add("active");
		startX = e.pageX - slider.offsetLeft;
		scrollLeft = slider.scrollLeft;
	});
	slider.addEventListener("mouseleave", () => {
		mouseApertado = false;
		slider.classList.remove("active");
	});
	slider.addEventListener("mouseup", () => {
		mouseApertado = false;
		slider.classList.remove("active");
	});
	slider.addEventListener("mousemove", (e) => {
		if (!mouseApertado) return; // se o mouse nao estiver apertado, sai do evento
		e.preventDefault();

		disableTeamButton();
		disableBoardButton();
		let x = e.pageX - slider.offsetLeft;
		let walk = (x - startX) * 3; //scroll-fast
		slider.scrollLeft = scrollLeft - walk;
	});
});

slider.forEach((slider) => {
	let mouseApertado = false;
	let startX;
	let scrollLeft;

	slider.addEventListener("touchstart", (e) => {
		mouseApertado = true;
		slider.classList.add("active");
		startX = e.changedTouches[0].pageX - slider.offsetLeft;
		scrollLeft = slider.scrollLeft;
	});
	slider.addEventListener("touchend", () => {
		mouseApertado = false;
		slider.classList.remove("active");
	});
	slider.addEventListener("touchleave", () => {
		mouseApertado = false;
		slider.classList.remove("active");
	});
	slider.addEventListener("touchmove", (e) => {
		if (!mouseApertado) return; // se o mouse nao estiver apertado, sai do evento
		e.preventDefault();

		disableTeamButton();
		disableBoardButton();
		let x = e.changedTouches[0].pageX - slider.offsetLeft;
		let walk = (x - startX) * 3; //scroll-fast
		slider.scrollLeft = scrollLeft - walk;
	});
});
